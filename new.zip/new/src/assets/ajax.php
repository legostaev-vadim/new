<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }

$error = '404';
if(!isset($_POST['page'])) {
	include('header.inc.php');
	getPageContent($error);
	include('footer.inc.php');
} else {
	$content = returnPageContent($_POST['page']);
	if($content) echo $content;
	else getPageContent($error);
}