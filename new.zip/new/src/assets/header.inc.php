<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<!DOCTYPE html>
<html lang="ru" data-name="<?php get_site_name(); ?>">
  <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <base href="<?php get_theme_url(); ?>/dist">
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet"/>
    <title><?php echo ($error) ? $error : return_page_title(); ?> | <?php get_site_name(); ?></title>
    <link rel="stylesheet" href="build.css"/>
    <?php get_header(); ?>
  </head>
  <body>
    <?php get_component('header'); ?>
    <main>