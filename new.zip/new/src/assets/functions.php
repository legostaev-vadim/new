<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }

function get_custom_menu($item = 'menu__item', $current = 'current') {
	$pageSlug = return_page_slug();
	$itemClass = $item;
	$currentClass = "{$itemClass}--{$current}";
	foreach (menu_data() as $item) {
		if($item['menu_status']) {
			if($item['slug'] == $pageSlug) $class = $itemClass . ' ' . $currentClass;
			else $class = $itemClass;
			echo "<a class='$class' href='{$item['url']}'>{$item['menu_text']}</a>";
		}
	}
}