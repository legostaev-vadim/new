<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
</main>
    <?php get_component('footer'); ?>
    <button class="button-up"></button>
    <script src="build.js"></script>
  </body>
</html>