<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }

include('header.inc.php');
get_page_content();
include('footer.inc.php');