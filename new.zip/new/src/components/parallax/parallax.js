plugins.parallax = ($ = jQuery) => {

  const $parallax = $('.parallax');

  $('.parallax-mirror').remove();

  $('.parallax').parallax({
    imageSrc: $parallax.data('image'),
    speed: $parallax.data('speed')
  });

};