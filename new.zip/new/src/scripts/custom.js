var wow = new WOW();
wow.init();
const plugins = {};