(function($ = jQuery) {

  route.start();
  route.base('/');

	let $html = $('html');
	let $title = $('title');
  let $main = $('main');
	let $menu = $('.menu');
	let $page = $menu.find('.menu__page');
  let $items = $menu.find('.menu__item');
	let siteName = $('html').data('name');
	let upward  = $main.data('up');

	function scroll() {
		let duration = 600;
		let top = $main.offset().top - upward;
    if($html.scrollTop() == parseInt(top)) duration = 100;
		$html.stop().animate({scrollTop : top}, duration);
		return false;
  }

	$items.filter('.menu__item--current').on('click', scroll);
	$page.on('click', scroll);

	for (const key in plugins) plugins[key]();

  route(function(path) {
		$items.removeClass('menu__item--current');
		$items.off('click');

		$main.load('ajax', {page: path || 'index'}, () => {
			$('.menu').removeClass('menu--open').animate({scrollTop : 0}, 300);
			for (const key in plugins) plugins[key]();
			wow.stop();
      $html.scrollTop($main.offset().top - upward);
      wow.start();
		}).attr('id', path || 'home');

		let href = (path) ? document.location.href + '/' : document.location.href;
		let $current = $items.filter(`[href="${href}"]`)
		let itemText = $current.addClass('menu__item--current').on('click', scroll).text();
    
		$title.text(itemText + ' | ' + siteName);
		$page.text(itemText);
  });

})();