let gulp = require('gulp');
let pug = require('gulp-pug');
let pugbem = require('gulp-pugbem');
let sass = require('gulp-sass');
let autoprefixer = require('gulp-autoprefixer');
let cleanCSS = require('gulp-clean-css');
let csscomb = require('gulp-csscomb');
let babel = require('gulp-babel');
let uglify = require('gulp-uglify');
let save = require('gulp-save');
let remember = require('gulp-remember');
let concat = require('gulp-concat');
let flatmap = require('gulp-flatmap');
let merge2 = require('merge2');
let gulpIf = require('gulp-if');
let browserSync = require('browser-sync').create();
let svgSprite = require('gulp-svg-sprites');
let multipipe = require('multipipe');
let del = require('del');
let sincePages;
let saveComps;
let isSymbol;
let isBuild;
let isRoute;
let paths;

function files(done) {
  paths = {
    comps: [
      'src/pages/helpers/variables.pug',
      'src/pages/helpers/mixins.pug',
      'src/components/**/*.pug'
    ],
    pages: [
        'src/index.pug',
        'src/pages/*.pug'
    ],
    styles: [
      'node_modules/normalize.css/normalize.css',
      'src/libs/jquery.simple-popup.min.css',
      'src/libs/animate.min.css',
      'src/libs/bootstrap.css',
      'src/styles/helpers/variables.scss',
      'src/styles/helpers/mixins.scss',
      'src/styles/helpers/fonts.scss',
      'src/styles/custom.scss',
      'src/styles/main.scss',
      'src/components/**/*.scss'
    ],
    scripts: [
      'node_modules/jquery/dist/jquery.js',
      'node_modules/riot-route/dist/route.js',
      'src/libs/jquery.simple-popup.min.js',
      'src/libs/jquery.validate.min.js',
      'src/libs/wow.min.js',
      'src/libs/parallax.js',
      'src/scripts/custom.js',
      'src/components/**/*.js',
      isRoute ? 'src/scripts/route/server.js' : 'src/scripts/route/local.js'
    ],
    symbols: 'src/symbols/**/*.svg',
    copy: 'src/assets/**/*',
    dest: 'dist'
  };
  done();
}

function comps() {
  return saveComps = gulp.src(paths.comps, {since: gulp.lastRun(comps)})
    .pipe(remember('comps'))
    .pipe(save('comps'))
    .on('end', () => {sincePages = undefined; remember.forgetAll('pages')});
}

function pages() {
  return gulp.src(paths.pages, {since: sincePages})
    .pipe(flatmap(function(stream, file) {
      return merge2(saveComps.pipe(save.restore('comps')), stream)
        .pipe(concat(file.basename));
    }))
    .pipe(pug({pretty: true, plugins: [pugbem]}))
    .pipe(remember('pages'))
    .pipe(gulpIf('index.html', gulp.dest(paths.dest), gulp.dest(paths.dest + '/pages')))
    .on('end', () => sincePages = gulp.lastRun(pages));
}

function styles() {
  return gulp.src(paths.styles, {since: gulp.lastRun(styles)})
    .pipe(remember('styles'))
    .pipe(gulpIf('*.scss', multipipe(
      concat('build.scss'),
      sass()
    )))
    .pipe(concat('build.css'))
    .pipe(gulpIf(isBuild, multipipe(
      autoprefixer({browsers:['last 15 versions']}),
      csscomb(),
      cleanCSS()
    )))
    .pipe(gulp.dest(paths.dest));
}

function scripts() {
  return gulp.src(paths.scripts, {since: gulp.lastRun(scripts)})
    .pipe(remember('scripts'))
    .pipe(concat('build.js'))
    .pipe(gulpIf(isBuild, multipipe(
      babel({
        presets: ['@babel/env'],
        sourceType: 'unambiguous'
      }),
      uglify()
    )))
    .pipe(gulp.dest(paths.dest));
}

function symbols(done) {
  if(!isSymbol) done();
  else return gulp.src(paths.symbols)
    .pipe(svgSprite({
      mode: 'symbols',
      preview: false,
      svg: {
          symbols: 'build.svg'
      }
    }))
    .pipe(gulp.dest(paths.dest));
}

function serve(done) {
  browserSync.init({
    server: {
        baseDir: paths.dest
    },
    open: false,
    notify: false
  });
  done();
}

function reload(done) {
  browserSync.reload();
  done();
}

function clean() {
  return del(paths.dest);
}

function copy(done) {
  gulp.src(paths.copy).pipe(gulp.dest(paths.dest));
  done();
}

function build(done) {
  isBuild = true;
  done();
}

function route(done) {
  isRoute = true;
  done();
}

function watch() {
  gulp.watch(paths.comps, gulp.series(comps, pages, reload));
  gulp.watch(paths.pages, gulp.series(pages, reload));
  gulp.watch(paths.styles, gulp.series(styles, reload));
  gulp.watch(paths.scripts, gulp.series(scripts, reload));
  gulp.watch(paths.symbols, gulp.series(symbols, reload));
  gulp.watch(paths.copy, gulp.series(copy, reload));
}

let dev = gulp.series(files, clean, copy, comps, gulp.parallel(pages, styles, scripts, symbols), serve, watch);
let bul = gulp.series(build, dev);
let rot = gulp.series(route, bul);

gulp.task('default', dev);
gulp.task('build', bul);
gulp.task('route', rot);